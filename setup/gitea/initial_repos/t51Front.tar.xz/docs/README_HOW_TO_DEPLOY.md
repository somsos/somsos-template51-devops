# How to deploy

## Deployment mode

Just run the following command to start the application in development mode:

```bash
npm run start
```
