# Workflow in DevOps

## Cheat sheet

```shell
psql postgresql://t51DB_user:t51DB_pass@mariomv-local.org:5001/t51DB_schema
```


## Requirements

1, Just use the `update` and tag commands, and everything else must be set so
this commands do the expected.
