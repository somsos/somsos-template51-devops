package daj.adapter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.log4j.Log4j2;

@Log4j2
@SpringBootApplication(
	scanBasePackages = {
		"daj.product",
		"daj.user",
		"daj.adapter.product",
		"daj.adapter.common",
		"daj.adapter.user",
		"daj.adapter.errorHandler",
	}
)
public class AdapterApplication {

	public static void main(String[] args) {
		log.info("######### VERSION: 0.7 #########");
		SpringApplication.run(AdapterApplication.class, args);
	}

}
