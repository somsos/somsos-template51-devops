export const environment = {
  backend: {
    mock: false,
    // CAREFUL: '__MY_DOMAIN__' is looked by front.dockerfile to remplace and build according to environment
    path: '__BACK_URL__', 
  },
  
  production: true,
  img404: '/img/404.png',
};

