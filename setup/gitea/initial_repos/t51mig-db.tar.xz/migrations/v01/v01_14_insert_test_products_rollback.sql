
-- v01_14_insert_test_products.sql

-- \echo 'Starts v01_14_insert_test_products.sql';

DELETE FROM product_images WHERE id IN (1, 2, 3, 4, 5, 6, 7);

DELETE FROM products WHERE id IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21);

SELECT setval('products_id_seq', 1, true);

SELECT setval('product_images_id_seq', 1, true);

-- \echo 'Ends v01_14_insert_test_products.sql';
