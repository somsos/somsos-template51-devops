# Workflow in DevOps

## Requirements

1, Just use the `update` and tag commands, and everything else must be set so
this commands do the expected.
