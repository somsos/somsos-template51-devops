# How to use in local or developing

1, We need an instance of postgres with the same credentials in `liquibase.properties`,

```shell
docker run -d --rm --name t51DB_local \
  -e POSTGRES_DB=t51DB_local_schema \
  -e POSTGRES_USER=t51DB_local_user \
  -e POSTGRES_PASSWORD=t51DB_local_pass \
  -p 5003:5432 \
  postgres:17.6-alpine3.22 -c log_statement=all

# Checking
psql postgresql://t51DB_local_user:t51DB_local_pass@localhost:5003/t51DB_local_schema

```

## Common workflow

```sql
liquibase update-to-tag --tag=v01
```

## Cheat sheet

At the root level of the project we can run the following commands.

```shell
# CAREFUL: Duplicated in {journal}/dev/java/liquibase.md > Cheat sheet

# check changes pending and applied
liquibase status

# Apply all pending migrations
liquibase update

# Rollback 1 migration
liquibase rollbackCount 1

# See changes applied
liquibase history

# Create project
liquibase init project

# Rollback to tag
liquibase rollback vXX
```

Command to include vars in command

```shell
docker run --name template51_liquibase_migration --rm \
  -v ./:/var/liquibase \
  -w /var/liquibase \
  -e DB_NAME=${DB_NAME} \
  -e DB_USER=${DB_USER} \
  -e DB_PASSWORD=${DB_PASSWORD} \
  -e DB_URL=${DB_URL} \
  liquibase:4.33-alpine \
  liquibase update \
    --username=$DB_USER \
    --password=$DB_PASSWORD \
    --url=$DB_URL

```

<!--

■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

-->

----

<!--

■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

-->

## Pitfalls

### Error: Cannot find database driver: org.postgresql.Driver

Running the command `liquibase status` I got this error, in my case I solved it

1. Downloading the jar in `https://jdbc.postgresql.org/download/`
2. Moving it to `/opt/liquibase/internal/lib/`


<!--

■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

-->

----

<!--

■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

-->


## Useful Commands 

### DANGER

```sql
-- reset
drop table if exists tests;
drop table if exists product_images;
drop table if exists products;
drop table if exists users_roles;
drop table if exists roles;
drop table if exists users;
drop table if exists users_picture;
drop table if exists databasechangelog;
drop table if exists databasechangeloglock;
```

